const userId = process.env.TIENDANUBE_USER_ID
const token = process.env.TIENDANUBE_ACCESS_TOKEN
const clientId = process.env.TIENDANUBE_CLIENT_ID

export interface TiendanubeImage {
  src?: string
  original_src?: string
}

export interface TiendanubeVariant {
  id: number
  price?: string
  compare_at_price?: string
  values?: Array<{ es?: string }>
}

export interface TiendanubeProduct {
  id: number
  name?: { es?: string }
  description?: { es?: string }
  images?: TiendanubeImage[]
  variants?: TiendanubeVariant[]
}

const headers = {
  'Authentication': `bearer ${token}`,
  'User-Agent': `MyCode App ${clientId}`,
  'Content-Type': 'application/json',
}

async function tiendanubeFetch<T>(path: string) {
  const response = await fetch(
    `https://api.tiendanube.com/v1/${userId}${path}`,
    { headers, next: { revalidate: 60 } }
  )

  return response.json() as Promise<T>
}

export async function getProducts() {
  return tiendanubeFetch<TiendanubeProduct[]>('/products?per_page=50')
}

export async function getProductsByCategory(categoryId: string) {
  return tiendanubeFetch<TiendanubeProduct[]>(`/products?category_id=${categoryId}&per_page=50`)
}

export async function getProduct(id: string) {
  return tiendanubeFetch<TiendanubeProduct>(`/products/${id}`)
}
