import { NextRequest, NextResponse } from 'next/server'
import type { CartItem } from '../../CartContext'

const userId = process.env.TIENDANUBE_USER_ID
const token = process.env.TIENDANUBE_ACCESS_TOKEN
const clientId = process.env.TIENDANUBE_CLIENT_ID

export async function POST(req: NextRequest) {
  const { items } = await req.json() as { items: CartItem[] }

  const products = items.map((item) => ({
    variant_id: item.variantId,
    quantity: item.quantity
  }))

  const response = await fetch(
    `https://api.tiendanube.com/v1/${userId}/draft_orders`,
    {
      method: 'POST',
      headers: {
        'Authentication': `bearer ${token}`,
        'User-Agent': `MyCode App ${clientId}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contact_email: 'cliente@mycode.com',
        contact_name: 'Cliente',
        contact_lastname: 'MyCode',
        products
      })
    }
  )

  const order = await response.json()
  const checkoutUrl = order.abandoned_checkout_url || order.checkout_url

  return NextResponse.json({ checkoutUrl })
}
