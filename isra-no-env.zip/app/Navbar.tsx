'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { useCart } from './CartContext'
import Cart from './Cart'
import styles from './navbar.module.css'

const CATEGORIAS = [
  { nombre: 'Todas', href: '/' },
  { nombre: 'Remeras', href: '/categoria/remeras' },
  { nombre: 'Buzos', href: '/categoria/buzos' },
  { nombre: 'Pantalones', href: '/categoria/pantalones' },
]

export default function Navbar() {
  const { count } = useCart()
  const [cartOpen, setCartOpen] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <>
      <nav className={styles.nav}>
        <Link href="/" className={styles.logo}>MYCODE</Link>

        <div className={styles.navLinks}>
          {/* Dropdown Colección */}
          <div className={styles.dropdown} ref={dropdownRef}>
            <button
              className={styles.dropdownTrigger}
              onClick={() => setDropdownOpen(prev => !prev)}
            >
              Colección
              <span className={`${styles.arrow} ${dropdownOpen ? styles.arrowUp : ''}`}>▾</span>
            </button>
            {dropdownOpen && (
              <div className={styles.dropdownMenu}>
                {CATEGORIAS.map((cat) => (
                  <Link
                    key={cat.href}
                    href={cat.href}
                    className={styles.dropdownItem}
                    onClick={() => setDropdownOpen(false)}
                  >
                    {cat.nombre}
                  </Link>
                ))}
              </div>
            )}
          </div>
          <a href="#">Contacto</a>
        </div>

        <button className={styles.cartBtn} onClick={() => setCartOpen(true)}>
          CARRITO {count > 0 && <span className={styles.badge}>{count}</span>}
        </button>
      </nav>

      {cartOpen && <Cart onClose={() => setCartOpen(false)} />}
    </>
  )
}