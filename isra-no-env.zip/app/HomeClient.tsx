'use client'

import styles from './page.module.css'
import { motion } from 'framer-motion'
import Link from 'next/link'
import type { TiendanubeProduct } from './lib/tiendanube'

const MotionLink = motion(Link)

interface HomeClientProps {
  products: TiendanubeProduct[]
  titulo?: string
}

export default function HomeClient({ products, titulo }: HomeClientProps) {
  return (
    <main className={styles.main}>

      {/* Muestra el hero solo en la página principal */}
      {!titulo && (
        <section className={styles.hero}>
          <div className={styles.heroBg} />
          <motion.div
            className={styles.heroContent}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: 'easeOut' }}
          >
            <motion.p className={styles.heroTag} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3, duration: 0.8 }}>
              Nueva colección
            </motion.p>
            <motion.h1 className={styles.heroTitle} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.9 }}>
              CONSIGUE<br />TÚ E-COMMERCE
            </motion.h1>
            <motion.p className={styles.heroSub} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8, duration: 0.8 }}>
              Vende tus productos y servicios, sin limite
            </motion.p>
            <motion.a href="#productos" className={styles.heroBtn} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1, duration: 0.8 }}>
              Ver colección
            </motion.a>
          </motion.div>
        </section>
      )}

      {/* Título de categoría */}
      {titulo && (
        <motion.div
          className={styles.categoriaHeader}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/" className={styles.categoriaBack}>← Volver</Link>
          <h1 className={styles.categoriaTitulo}>{titulo}</h1>
        </motion.div>
      )}

      <section className={styles.productos} id="productos">
        {!titulo && (
          <motion.h2 className={styles.secTitle} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            COLECCIÓN
          </motion.h2>
        )}
        <div className={styles.grid}>
          {products?.map((product, i) => (
            <MotionLink
              href={`/producto/${product.id}`}
              className={styles.card}
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <div className={styles.cardImg}>
                {product.images && product.images[0] && (
                  <img
                    src={product.images[0].src}
                    alt={product.name?.es || 'Producto'}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                )}
              </div>
              <div className={styles.cardInfo}>
                <span className={styles.cardName}>{product.name?.es}</span>
                <span className={styles.cardPrice}>
                  ${Number(product.variants?.[0]?.price ?? 0).toLocaleString('es-AR', { maximumFractionDigits: 0 })}
                </span>
              </div>
            </MotionLink>
          ))}
        </div>
      </section>

      <footer className={styles.footer}>
        <span className={styles.logo}>MYCODE</span>
        <p>© 2026 MyCode. Todos los derechos reservados.</p>
      </footer>

    </main>
  )
}
