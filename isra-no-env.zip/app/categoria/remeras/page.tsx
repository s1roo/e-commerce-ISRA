import { getProductsByCategory } from '../../lib/tiendanube'
import HomeClient from '../../HomeClient'

export default async function CategoriaPage() {
  const products = await getProductsByCategory('38863431')
  return <HomeClient products={products} titulo="REMERAS" />
}
