import { getProductsByCategory } from '../../lib/tiendanube'
import HomeClient from '../../HomeClient'

export default async function CategoriaPage() {
  const products = await getProductsByCategory('38863409')
  return <HomeClient products={products} titulo="PANTALONES" />
}
