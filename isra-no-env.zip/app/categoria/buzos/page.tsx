import { getProductsByCategory } from '../../lib/tiendanube'
import HomeClient from '../../HomeClient'

export default async function CategoriaPage() {
  const products = await getProductsByCategory('38863193')
  return <HomeClient products={products} titulo="BUZOS" />
}
