'use client'

import { useCart } from './CartContext'
import styles from './cart.module.css'

export default function Cart({ onClose }: { onClose: () => void }) {
  const { items, removeItem, updateQuantity, total, count } = useCart()

  const checkout = async () => {
    if (items.length === 0) return
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items })
      })
      const data = await response.json()
      if (data.checkoutUrl) {
        window.open(data.checkoutUrl, '_blank')
      }
    } catch (error) {
      console.error('Error al crear checkout:', error)
    }
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.cart} onClick={e => e.stopPropagation()}>
        <div className={styles.header}>
          <h2 className={styles.title}>CARRITO ({count})</h2>
          <button className={styles.close} onClick={onClose}>✕</button>
        </div>

        {items.length === 0 ? (
          <p className={styles.empty}>Tu carrito está vacío</p>
        ) : (
          <>
            <div className={styles.items}>
              {items.map(item => (
                <div className={styles.item} key={`${item.id}-${item.variantId}`}>
                  <img src={item.image} alt={item.name} className={styles.itemImg} />
                  <div className={styles.itemInfo}>
                    <p className={styles.itemName}>{item.name}</p>
                    <p className={styles.itemSize}>Talle: {item.size}</p>
                    <p className={styles.itemPrice}>${Number(item.price).toLocaleString('es-AR')}</p>
                    <div className={styles.qty}>
                      <button onClick={() => updateQuantity(item.id, item.variantId, item.quantity - 1)}>−</button>
                      <span>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, item.variantId, item.quantity + 1)}>+</button>
                    </div>
                  </div>
                  <button className={styles.remove} onClick={() => removeItem(item.id, item.variantId)}>✕</button>
                </div>
              ))}
            </div>

            <div className={styles.footer}>
              <div className={styles.totalRow}>
                <span>TOTAL</span>
                <span>${total.toLocaleString('es-AR')}</span>
              </div>
              <button className={styles.checkoutBtn} onClick={checkout}>
                Finalizar compra
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}