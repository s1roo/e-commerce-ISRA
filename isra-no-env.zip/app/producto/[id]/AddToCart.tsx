'use client'

import { useState } from 'react'
import { useCart } from '../../CartContext'
import styles from './product.module.css'
import type { TiendanubeProduct, TiendanubeVariant } from '../../lib/tiendanube'

export default function AddToCart({ product, image, name, price }: {
  product: TiendanubeProduct
  image?: string
  name: string
  price: number
}) {
  const { addItem } = useCart()
  const [selectedVariant, setSelectedVariant] = useState<TiendanubeVariant | null>(null)
  const [error, setError] = useState(false)
  const [added, setAdded] = useState(false)

  const variants = product.variants || []

  const handleAdd = () => {
    if (!selectedVariant) {
      setError(true)
      setTimeout(() => setError(false), 2000)
      return
    }
    addItem({
      id: product.id,
      variantId: selectedVariant.id,
      name,
      price,
      image: image ?? '',
      size: selectedVariant.values?.[0]?.es || '',
      quantity: 1,
    })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div className={styles.addToCart}>
      <p className={styles.sizeLabel}>TALLE</p>
      <div className={styles.sizes}>
        {variants.map((v) => (
          <button
            key={v.id}
            className={`${styles.sizeBtn} ${selectedVariant?.id === v.id ? styles.selected : ''}`}
            onClick={() => { setSelectedVariant(v); setError(false) }}
          >
            {v.values?.[0]?.es || v.id}
          </button>
        ))}
      </div>
      {error && <p className={styles.errorMsg}>⚠ Seleccioná un talle antes de continuar</p>}
      <button
        className={`${styles.buyBtn} ${added ? styles.addedBtn : ''}`}
        onClick={handleAdd}
      >
        {added ? '✓ AGREGADO AL CARRITO' : 'AGREGAR AL CARRITO'}
      </button>
    </div>
  )
}
