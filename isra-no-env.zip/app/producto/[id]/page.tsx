import { notFound } from 'next/navigation'
import styles from './product.module.css'
import { getProduct } from '../../lib/tiendanube'
import AddToCart from './AddToCart'

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = await getProduct(id)
  if (!product || Array.isArray(product)) notFound()
  const image = product.images?.[0]?.src || product.images?.[0]?.original_src
  const rawPrice = product.variants?.[0]?.price || product.variants?.[0]?.compare_at_price || '0'
  const price = Number(rawPrice).toLocaleString('es-AR', { maximumFractionDigits: 0 })
  const priceNumber = parseFloat(rawPrice)
  const name = product.name?.es || 'Producto'
  const description = product.description?.es || ''
  const cleanDescription = description.replace(/<[^>]*>/g, '').replace(/&aacute;/g, 'á').replace(/&eacute;/g, 'é').replace(/&iacute;/g, 'í').replace(/&oacute;/g, 'ó').replace(/&uacute;/g, 'ú').replace(/&ntilde;/g, 'ñ').replace(/&quot;/g, '"').replace(/&amp;/g, '&')

  return (
    <main className={styles.main}>
      <div className={styles.container}>
        <div className={styles.imageBox}>
          {image ? (
            <img src={image} alt={name} className={styles.image} />
          ) : (
            <div className={styles.noImage} />
          )}
        </div>
        <div className={styles.info}>
          <p className={styles.tag}>MyCode</p>
          <h1 className={styles.name}>{name}</h1>
          <p className={styles.price}>${price}</p>
          {cleanDescription && <p className={styles.description}>{cleanDescription}</p>}
          <AddToCart product={product} image={image} name={name} price={priceNumber} />
        </div>
      </div>
    </main>
  )
}
