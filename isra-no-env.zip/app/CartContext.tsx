'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

export interface CartItem {
  id: number
  variantId: number
  name: string
  price: number
  image: string
  size: string
  quantity: number
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (id: number, variantId: number) => void
  updateQuantity: (id: number, variantId: number, qty: number) => void
  total: number
  count: number
  clearCart: () => void
}

const CartContext = createContext<CartContextType | null>(null)
const CART_STORAGE_KEY = 'mycode-cart'

function getInitialCart(): CartItem[] {
  if (typeof window === 'undefined') return []

  try {
    const saved = localStorage.getItem(CART_STORAGE_KEY)
    return saved ? JSON.parse(saved) : []
  } catch {
    return []
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(getInitialCart)

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items))
  }, [items])

  const addItem = (item: CartItem) => {
    setItems(prev => {
      const existing = prev.find(i => i.id === item.id && i.variantId === item.variantId)
      if (existing) {
        return prev.map(i =>
          i.id === item.id && i.variantId === item.variantId
            ? { ...i, quantity: i.quantity + 1 }
            : i
        )
      }
      return [...prev, item]
    })
  }

  const removeItem = (id: number, variantId: number) => {
    setItems(prev => prev.filter(i => !(i.id === id && i.variantId === variantId)))
  }

  const updateQuantity = (id: number, variantId: number, qty: number) => {
    if (qty <= 0) {
      removeItem(id, variantId)
      return
    }
    setItems(prev =>
      prev.map(i =>
        i.id === id && i.variantId === variantId ? { ...i, quantity: qty } : i
      )
    )
  }

  const clearCart = () => setItems([])

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0)
  const count = items.reduce((sum, i) => sum + i.quantity, 0)

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, total, count, clearCart }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
